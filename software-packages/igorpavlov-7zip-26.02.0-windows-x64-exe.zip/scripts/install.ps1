$ErrorActionPreference = 'Stop'
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Resolve-Path (Join-Path $scriptDir '..')
$installerPath = Join-Path $root 'payload\\7z2602-x64.exe'

if (-not (Test-Path -LiteralPath $installerPath)) {
    throw "Installer not found at $installerPath"
}

$process = Start-Process -FilePath $installerPath -ArgumentList '/S' -PassThru -Wait
if ($process.ExitCode -notin @(0, 3010)) {
    throw "Install failed with exit code $($process.ExitCode)"
}

exit $process.ExitCode