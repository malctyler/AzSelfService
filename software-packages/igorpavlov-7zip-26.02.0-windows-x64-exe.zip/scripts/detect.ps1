$detectPath = 'C:\Program Files\7-Zip\7z.exe'
if (Test-Path -LiteralPath $detectPath) {
    Write-Host 'Detected package.'
    exit 0
}

Write-Host "Package not detected at $detectPath"
exit 1