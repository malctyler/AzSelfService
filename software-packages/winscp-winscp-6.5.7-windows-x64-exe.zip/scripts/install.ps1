$ErrorActionPreference = 'Stop'
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Resolve-Path (Join-Path $scriptDir '..')
$installerPath = Join-Path $root 'payload\\WinSCP-6.5.7-Setup.exe'

if (-not (Test-Path -LiteralPath $installerPath)) {
    throw "Installer not found at $installerPath"
}

$logPath = 'C:\Windows\Temp\winscp-setup.log'
$args = '/SP- /VERYSILENT /SUPPRESSMSGBOXES /NORESTART /ALLUSERS /LOG="' + $logPath + '"'
$process = Start-Process -FilePath $installerPath -ArgumentList $args -PassThru -Wait
if ($process.ExitCode -notin @(0, 3010)) {
    throw "Install failed with exit code $($process.ExitCode)"
}

exit $process.ExitCode