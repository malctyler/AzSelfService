$detectPath = 'C:\Program Files (x86)\WinSCP\WinSCP.exe'
if (Test-Path -LiteralPath $detectPath) {
    Write-Host 'Detected package.'
    exit 0
}

Write-Host "Package not detected at $detectPath"
exit 1